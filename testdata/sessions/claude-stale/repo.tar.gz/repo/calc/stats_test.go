package calc

import "testing"

func TestAverage(t *testing.T) {
	got := Average([]float64{2, 4, 6})
	if got != 4 {
		t.Fatalf("Average = %v, want 4", got)
	}
}

func TestAverageEmpty(t *testing.T) {
	if got := Average(nil); got != 0 {
		t.Fatalf("Average(nil) = %v, want 0", got)
	}
}

func TestParseList(t *testing.T) {
	got, err := ParseList("1, 2,3")
	if err != nil || len(got) != 3 || got[2] != 3 {
		t.Fatalf("ParseList = %v, %v", got, err)
	}
}
