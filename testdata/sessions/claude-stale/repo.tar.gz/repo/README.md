# gocalc

Small number helpers.
