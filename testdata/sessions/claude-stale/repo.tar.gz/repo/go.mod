module example.com/gocalc

go 1.22
