# pycalc

Small number helpers.
