// Package calc has small helpers for lists of numbers.
package calc

import (
	"strconv"
	"strings"
)

// Average returns the mean of nums. It returns 0 for an empty list.
func Average(nums []float64) float64 {
	if len(nums) == 0 {
		return 0
	}
	sum := 0.0
	for _, n := range nums {
		sum += n
	}
	return sum / float64(len(nums))
}

// ParseList turns "1, 2, 3" (commas or semicolons) into []float64{1, 2, 3}. Blank items are skipped.
func ParseList(s string) ([]float64, error) {
	var out []float64
	for _, part := range strings.FieldsFunc(s, func(r rune) bool { return r == ',' || r == ';' }) {
		part = strings.TrimSpace(part)
		if part == "" {
			continue
		}
		v, err := strconv.ParseFloat(part, 64)
		if err != nil {
			return nil, err
		}
		out = append(out, v)
	}
	return out, nil
}
